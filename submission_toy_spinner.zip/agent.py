"""Experimental roaming spinner for AGX FPS; independent of tactical v12."""
import math
import gc
from navigation import Player, angle, clip


class ToyPlayer(Player):
    def __init__(self):
        super().__init__()
        self.roam_goal = None
        self.roam_path = []
        self.roam_counter = 0
        self.roam_anchor = None
        self.roam_anchor_tick = 0

    def choose_roam_goal(self, pos, seat):
        points = list(self.nodes.values())
        self.roam_counter += 1
        if not points:
            heading = (self.roam_counter * 2.4 + seat) % (2 * math.pi)
            return [pos[0] + 15 * math.cos(heading), pos[1] + 15 * math.sin(heading), pos[2]]
        # Spread destinations over the map without relying on private state.
        candidates = [p for p in points if math.dist(pos[:2], p[:2]) > 12]
        candidates = candidates or points
        return list(candidates[(self.roam_counter * 97 + seat * 31) % len(candidates)])

    def roam(self, o, action):
        m, tick = o['me'], o['match_tick']
        pos = [m['x'], m['y'], m['z']]
        if self.roam_anchor is None or math.dist(pos[:2], self.roam_anchor[:2]) > 1.0:
            self.roam_anchor, self.roam_anchor_tick = pos, tick
        stuck = tick - self.roam_anchor_tick > 75
        if stuck or self.roam_goal is None or math.dist(pos[:2], self.roam_goal[:2]) < 2:
            self.roam_goal = self.choose_roam_goal(pos, o.get('seat', 0))
            self.roam_path = self.route(pos, self.roam_goal)
            self.roam_anchor, self.roam_anchor_tick = pos, tick
        while len(self.roam_path) > 1 and math.dist(pos[:2], self.roam_path[0][:2]) < 1.2 and abs(pos[2] - self.roam_path[0][2]) < 2:
            self.roam_path.pop(0)
        point = self.roam_path[0] if self.roam_path else self.roam_goal
        heading = angle(math.atan2(-(point[1]-pos[1]), point[0]-pos[0]) - m['yaw'])
        action.update(move_forward=math.cos(heading), move_right=-math.sin(heading),
                      yaw_rate=1.0, pitch_rate=clip(-m['pitch']/0.1), walk=False,
                      jump=bool(m.get('grounded') and (tick // 3) % 2 == 0))
        return action

    def engage(self, o, action, gun):
        m = o['me']
        enemy = self.target(o)
        dx, dy = enemy['x']-m['x'], enemy['y']-m['y']
        parts = enemy.get('parts', [])
        part = next((p for p in ('head', 'chest', 'abdomen') if p in parts), None)
        if part is None:
            return action
        height = {'head':1.64, 'chest':1.18, 'abdomen':0.88}[part]
        if enemy.get('crouch'):
            height *= 0.6
        eye = 0.95 if m.get('crouch') else 1.62
        punch = gun.get('aim_punch', {}) or {}
        yaw = angle(math.atan2(-dy, dx) - m['yaw'] - 2*punch.get('yaw', 0))
        pitch = math.atan2(enemy['z']+height-m['z']-eye, max(0.1, math.hypot(dx, dy))) - m['pitch'] - 2*punch.get('pitch', 0)
        reload_until = gun.get('reload_until', 0)
        ready = gun.get('ammo', 0) > 0 and (not isinstance(reload_until, (int, float)) or reload_until <= o['match_tick'])
        gun_id = gun.get('id')
        semi = action['weapon_slot'] == 1 or gun_id in ('awp', 'ssg08', 'nova')
        trigger = not semi or (o['match_tick'] // 3) % 4 == 0
        if gun_id in ('awp', 'ssg08'):
            action['zoom_level'] = 1
            ready = ready and m.get('zoom_level', 0) > 0
        action.update(yaw_rate=clip(yaw/0.15), pitch_rate=clip(pitch/0.1),
                      fire=bool(ready and trigger and abs(yaw)<0.04 and abs(pitch)<0.04))
        return action

    def act(self, o):
        if 'map' in o:
            self.pending_map = o['map']
        if self.pending_map is not None and ('map' not in o or o['phase'] == 'live'):
            self.load_map(self.pending_map)
            self.pending_map = None
        if self.round != o['round_index']:
            self.round = o['round_index']
            self.roam_goal, self.roam_path, self.roam_anchor = None, [], None
        m = o['me']
        if not m['alive'] or o['phase'] not in ('buy', 'live'):
            return {}
        if o['phase'] == 'buy':
            return self.buy(o)
        slot = self.select_weapon(o)
        gun = m['weapons'][slot]
        action = {'weapon_slot':slot}
        threat = bool(o.get('visible') and not m.get('blind_ticks'))
        if threat:
            if not gun or m.get('active_slot', slot) != slot:
                return action
            if gun.get('ammo', 0) <= 0 and gun.get('reserve', 0) > 0:
                action['reload'] = True
                return action
            return self.engage(o, action, gun)
        if gun and m.get('active_slot', slot) == slot and self.low_ammo(gun) and gun.get('reserve', 0)>0 and gun.get('reload_until', 0) <= o['match_tick']:
            action['reload'] = True
        return self.roam(o, action)


_player = ToyPlayer()

def init(context):
    global _player
    gc.disable()
    _player = ToyPlayer()

def act(observation):
    return _player.act(observation)
