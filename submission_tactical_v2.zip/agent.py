"""FPS policy: coordinated defaults, tactical objectives, and public-map navigation.

Coordination is deterministic, not a messaging or shared-memory system.
All timing and tactical thresholds are heuristics to validate in real matches.
"""
import math
import gc
import heapq


def clip(value):
    return max(-1.0, min(1.0, value))


def distance(a, b):
    return math.sqrt(sum((x - y)**2 for x, y in zip(a, b)))


def angle(value):
    return (value + math.pi) % (2 * math.pi) - math.pi


class Player:
    def __init__(self):
        self.nodes, self.edges, self.sites = {}, {}, []
        self.pending_map = None
        self.path, self.goal = [], None
        self.round = None
        self.last_position, self.stuck = None, 0
        self.anchor, self.anchor_tick = None, 0
        self.escape_until, self.escape_yaw, self.escapes = 0, 0.0, 0
        self.last_seen_enemy, self.last_seen_tick = None, -10000
        self.path_risk_stamp = None
        self.buy_round, self.buy_mode = None, None

    def load_map(self, row):
        self.sites = row["sites"]
        self.nodes = {n["id"]: n["position"]
                      for n in row["nav"]["nodes"]}
        self.edges = {key: [] for key in self.nodes}
        for edge in row["nav"]["edges"]:
            if edge["kind"] != "ladder":
                self.edges[edge["from"]].append(edge["to"])
                if edge["kind"] == "walk":
                    self.edges[edge["to"]].append(edge["from"])

    def route(self, start, goal, danger=None):
        if not self.nodes:
            return [goal]
        first = min(self.nodes,
                    key=lambda k: distance(start, self.nodes[k]))
        last = min(self.nodes,
                   key=lambda k: distance(goal, self.nodes[k]))
        # Use physical edge length rather than simply counting graph edges.
        queue, costs, parent = [(0.0, 0, first)], {first: 0.0}, {first: None}
        serial = 0
        while queue:
            cost, _, here = heapq.heappop(queue)
            if cost != costs[here]:
                continue
            if here == last:
                break
            for there in self.edges[here]:
                edge_length = distance(self.nodes[here], self.nodes[there])
                # Risk is only a heuristic around this player's recent sighting.
                # It is not a visibility, cover, or teammate-position model.
                risk = 0.0
                if danger is not None:
                    middle = [(x + y) * 0.5 for x, y in zip(self.nodes[here], self.nodes[there])]
                    proximity = math.dist(middle[:2], danger[:2])
                    risk = max(0.0, 1.0 - proximity / 4.0) * 3.0
                new_cost = cost + edge_length * (1.0 + risk)
                if new_cost < costs.get(there, float("inf")):
                    costs[there], parent[there] = new_cost, here
                    serial += 1
                    heapq.heappush(queue, (new_cost, serial, there))
        if last not in parent:
            return [goal]
        path, cursor = [goal], last
        while cursor is not None:
            path.append(self.nodes[cursor])
            cursor = parent[cursor]
        return list(reversed(path))

    def buy(self, o):
        """Choose a round budget once, so repeated buy calls do not change modes.

        No score field is documented in the supplied kit, so this policy does not
        guess a match-point/force-buy signal. Thresholds are uncalibrated heuristics.
        """
        m = o["me"]
        if self.buy_round != o["round_index"]:
            self.buy_round = o["round_index"]
            rifle_price = 2700 if o["side"] == "attack" else 2900
            self.buy_mode = "full" if (m["weapons"][0] is not None or
                                       m["cash"] >= rifle_price + 650) else "save"
        if self.buy_mode == "save":
            return {}
        rifle = "ak47" if o["side"] == "attack" else "m4a1"
        price = 2700 if o["side"] == "attack" else 2900
        if m["weapons"][0] is None and m["cash"] >= price:
            return {"buy": rifle}
        if m["armor"] < 50 and m["cash"] >= 650:
            return {"buy": "armor"}
        if o["side"] == "defend" and not m["has_kit"] and m["cash"] >= 400:
            return {"buy": "defusekit"}
        return {}

    def target(self, o):
        """Rank visible enemies by range and our angle to them, not enemy intent."""
        me = o["me"]
        def threat(enemy):
            dx, dy = enemy["x"] - me["x"], enemy["y"] - me["y"]
            dist = math.hypot(dx, dy)
            angular_error = abs(angle(math.atan2(-dy, dx) - me["yaw"]))
            # The direction is our view angle; no enemy-facing data is assumed.
            return 1.0 / (3.0 + dist) + 0.04 * (1.0 - angular_error / math.pi)
        return max(o["visible"], key=threat)

    def choose_site(self, o):
        """Coordinate via round/seat only; no agent communication is assumed."""
        if not self.sites:
            return None
        base = o["round_index"] % len(self.sites)
        if o["side"] == "attack":
            return self.sites[base]  # all attackers use the same initial objective
        return self.sites[(base + o["seat"] % len(self.sites)) % len(self.sites)]

    def remember_enemy(self, o):
        """Keep a short-lived personal sighting, never a teammate's private view."""
        if o["visible"] and not o["me"]["blind_ticks"]:
            enemy = self.target(o)
            self.last_seen_enemy = [enemy["x"], enemy["y"], enemy["z"]]
            self.last_seen_tick = o["match_tick"]

    def hold(self, o, action):
        """Hold still and orient toward a recent sighting; otherwise scan slowly."""
        m = o["me"]
        if self.last_seen_enemy and o["match_tick"] - self.last_seen_tick < 180:
            dx = self.last_seen_enemy[0] - m["x"]
            dy = self.last_seen_enemy[1] - m["y"]
            yaw = angle(math.atan2(-dy, dx) - m["yaw"])
            action.update(yaw_rate=clip(yaw / 0.15), pitch_rate=clip(-m["pitch"] / 0.1))
        else:
            action.update(yaw_rate=0.12 if o["seat"] % 2 == 0 else -0.12,
                          pitch_rate=clip(-m["pitch"] / 0.1))
        # Holding intentionally is not a navigation failure.
        self.anchor, self.anchor_tick = None, o["match_tick"]
        return action

    def combat(self, o, action, gun):
        m = o["me"]
        enemy = self.target(o)
        dx, dy = enemy["x"]-m["x"], enemy["y"]-m["y"]
        heights = {"head": 1.64, "chest": 1.18, "abdomen": 0.88}
        part = next((p for p in ("chest", "head", "abdomen")
                     if p in enemy["parts"]), "chest")
        height = heights[part] * (0.6 if enemy["crouch"] else 1.0)
        eye = 0.95 if m["crouch"] else 1.62
        dz = enemy["z"] + height - m["z"] - eye
        punch = gun.get("aim_punch", {}) if gun else {}
        yaw = angle(math.atan2(-dy, dx) - m["yaw"]
                    - 2 * punch.get("yaw", 0.0))
        pitch = math.atan2(dz, max(0.1, math.hypot(dx, dy)))
        pitch -= m["pitch"] + 2 * punch.get("pitch", 0.0)
        ready = bool(gun and gun["ammo"]
                     and not gun["reload_until"])
        # Release the trigger between pistol shots.
        trigger = (action["weapon_slot"] == 0
                   or (o["match_tick"] // 3) % 4 == 0)
        action.update(yaw_rate=clip(yaw / 0.15),
                      pitch_rate=clip(pitch / 0.1), crouch=True,
                      fire=ready and trigger and abs(yaw) < 0.04
                      and abs(pitch) < 0.04)
        return action

    def move(self, o, goal, action):
        m = o["me"]
        pos = [m["x"], m["y"], m["z"]]
        tick = o["match_tick"]
        if tick < self.escape_until:
            yaw = angle(self.escape_yaw - m["yaw"])
            return dict(action, move_forward=0.9 * math.cos(yaw),
                        move_right=-0.9 * math.sin(yaw),
                        yaw_rate=clip(yaw / 0.15),
                        pitch_rate=clip(-m["pitch"] / 0.1), walk=False,
                        jump=bool(m["grounded"] and tick % 30 == 0))
        recent = (self.last_seen_enemy is not None and
                  0 <= tick - self.last_seen_tick < 180)
        risk_stamp = self.last_seen_tick if recent else None
        if self.goal != goal or not self.path or self.path_risk_stamp != risk_stamp:
            danger = self.last_seen_enemy if recent else None
            self.path, self.goal = self.route(pos, goal, danger), list(goal)
            self.path_risk_stamp = risk_stamp
        # Navmesh samples can be above the actual foot position on a slope.
        while (len(self.path) > 1 and
               math.dist(pos[:2], self.path[0][:2]) < 1.0 and
               abs(pos[2] - self.path[0][2]) < 2.0):
            self.path.pop(0)
        point = self.path[0]
        dx, dy = point[0]-pos[0], point[1]-pos[1]
        yaw = angle(math.atan2(-dy, dx) - m["yaw"])
        moved = (self.last_position is None
                 or distance(pos, self.last_position) > 0.01)
        self.stuck = 0 if moved else self.stuck + 1
        self.last_position = pos
        # Move toward the waypoint while looking toward a recent nearby sighting;
        # absent one, look one waypoint ahead along the current route.
        aim_point = (self.last_seen_enemy if recent and
                     math.dist(pos[:2], self.last_seen_enemy[:2]) < 25.0
                     else self.path[min(1, len(self.path) - 1)])
        aim_yaw = angle(math.atan2(-(aim_point[1] - pos[1]),
                                    aim_point[0] - pos[0]) - m["yaw"])
        action.update(move_forward=0.75 * math.cos(yaw),
                      move_right=-0.75 * math.sin(yaw),
                      yaw_rate=clip(aim_yaw / 0.15),
                      pitch_rate=clip(-m["pitch"] / 0.1), walk=False)
        if self.anchor is None or math.dist(pos[:2], self.anchor[:2]) > 0.6:
            self.anchor, self.anchor_tick = pos, tick
        if tick >= self.escape_until and tick - self.anchor_tick > 60:
            # Commit to leaving a blocked corner; small sidesteps must not
            # immediately reset recovery and send us into the same obstacle.
            self.escapes += 1
            turn = (1 if (o["seat"] + self.escapes) % 2 else -1)
            self.escape_yaw = m["yaw"] + turn * (1.2 + 0.4 * (self.escapes % 3))
            self.escape_until = tick + 120
            self.anchor, self.anchor_tick = pos, self.escape_until
            self.path = []
        if tick < self.escape_until:
            yaw = angle(self.escape_yaw - m["yaw"])
            action.update(move_forward=0.9 * math.cos(yaw),
                          move_right=-0.9 * math.sin(yaw),
                          yaw_rate=clip(yaw / 0.15),
                          jump=bool(m["grounded"] and tick % 30 == 0))
        elif point[2] - pos[2] > 0.45 and math.hypot(dx, dy) < 1.8:
            action["jump"] = bool(m["grounded"] and tick % 24 == 0)
        return action

    def act(self, o):
        if "map" in o:
            self.pending_map = o["map"]
        # The opening observation is large. Build the navigation graph on a
        # later buy callback so JSON decoding and graph work use separate budgets.
        if self.pending_map is not None and ("map" not in o or o["phase"] == "live"):
            self.load_map(self.pending_map)
            self.pending_map = None
        if self.round != o["round_index"]:
            self.round = o["round_index"]
            self.path, self.goal = [], None
            self.path_risk_stamp = None
            self.last_position, self.stuck = None, 0
            self.anchor, self.anchor_tick = None, 0
            self.escape_until, self.escapes = 0, 0
            self.last_seen_enemy, self.last_seen_tick = None, -10000
        m = o["me"]
        if not m["alive"] or o["phase"] not in ("buy", "live"):
            return {}
        if o["phase"] == "buy":
            return self.buy(o)
        slot = 0 if m["weapons"][0] is not None else 1
        gun = m["weapons"][slot]
        action = {"weapon_slot": slot}
        if gun and gun["ammo"] == 0 and gun["reserve"]:
            action["reload"] = True
        pos = [m["x"], m["y"], m["z"]]
        bomb = o["bomb"]
        site = self.choose_site(o)
        # The opening observation can arrive before the graph is prepared.
        if site is None:
            return action
        goal = list(site["center"])
        planted = bomb["state"] == "planted" and bool(bomb.get("position"))
        if planted:
            goal = list(bomb["position"])
        if o["side"] == "attack" and bomb["state"] == "world" and bomb.get("position"):
            goal = list(bomb["position"])

        self.remember_enemy(o)
        can_fight = bool(o["visible"] and not m["blind_ticks"] and gun
                         and gun["ammo"] and not gun["reload_until"])
        # Deal with an immediate visible threat before committing to an objective.
        # Without a documented bomb timer, this may be wrong near detonation.
        if can_fight:
            return self.combat(o, action, gun)
        if o["side"] == "attack" and bomb["state"] == "world" and bomb.get("position"):
            if distance(pos, goal) < 1.2:
                return dict(action, use="pickup", pickup_id=bomb["id"])
        if o["side"] == "defend" and planted and distance(pos, goal) < 2.0:
            return dict(action, use="defuse")
        if (m["carrying_bomb"] and bomb["state"] != "planted"
                and distance(pos, site["center"]) < site["radius"] * 0.5):
            return dict(action, use="plant")

        # Hold the assigned area rather than repeatedly running into its centre.
        # Seat parity gives defenders a small spread without inventing map points.
        if o["side"] == "defend" and not planted:
            if distance(pos, goal) < max(2.0, site["radius"] * 0.65):
                return self.hold(o, action)
        if o["side"] == "attack" and planted and distance(pos, goal) < 8:
            return self.hold(o, action)

        # Stagger the departure, but avoid waiting 6–12 seconds at the spawn.
        if not planted and o["round_tick"] < (o["seat"] % 5) * 12:
            return action
        return self.move(o, goal, action)


_player = Player()


def init(context):
    global _player
    # Observations and this policy use acyclic containers; reference counting
    # releases them without repeatedly scanning the large public map.
    gc.disable()
    _player = Player()


def act(observation):
    return _player.act(observation)
